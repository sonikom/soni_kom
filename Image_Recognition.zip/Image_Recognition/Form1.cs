﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

using FANNCSharp;
#if FANN_FIXED
using FANNCSharp.Fixed;
using DataType = System.Int32;
#elif FANN_DOUBLE
using FANNCSharp.Double;
using DataType = System.Double;
#else
using FANNCSharp.Float;
using DataType = System.Single;
#endif

namespace Image_Recognition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int NFIGURES = 5;

        Random rnd;
        Bitmap bmp, pic1, pic2, pic_guess, cropped1, cropped2, compressed1, compressed2;
        Graphics g1, g2, g_guess;
        Pen p, pen_line;
        SolidBrush background, b;
        Rectangle cloneRect, arc, bounds;
        Point lastPoint = Point.Empty;
        Point[] points;
        GraphicsPath path;
        int pen_width, x, y, w, h, cropx1, cropy1, cropx2, cropy2, side, x0, y0, data_amount, figure, seed, diameter;
        bool empty;
        bool mouseDown = false;
        string line, tmp_string;
        string[] figure_names;
        double[] percentage;
        double tmp_double;
        NeuralNet net;
        float[] input;
        float[] output;
        

        private void Form1_Load(object sender, EventArgs e)
        {
            background = new SolidBrush(Color.White);
            b = new SolidBrush(Color.Black);
            
            cmbFigure.SelectedIndex = 0;
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            //создание исходного изображения
            pic2 = generate_pic(cmbFigure.SelectedIndex);
            picInput2.Image = pic2;

            //обрезка
            cropped2 = crop_pic(pic2);

            //сжатие до 10 на 10
            compressed2 = compress_pic(cropped2, 10, 10);
            picCompressed2.Image = compressed2;

        }

        private void btnGenerateData_Click(object sender, EventArgs e)
        {
            //генерация базы
            if (int.TryParse(txtDataAmount.Text, out data_amount))
            {
                prbGeneration.Maximum = data_amount;
                File.WriteAllText("training.data", "");
                StreamWriter sw = new StreamWriter("training.data");
                line = data_amount.ToString() + " 100 " + NFIGURES.ToString();
                sw.WriteLine(line);
                
                for (int i = 1; i <= data_amount; i++)
                {
                    seed = System.Environment.TickCount + i;
                    rnd = new Random(seed);
                    figure = rnd.Next(NFIGURES);
                    pic2 = generate_pic(figure);
                    cropped2 = crop_pic(pic2);
                    compressed2 = compress_pic(cropped2, 10, 10);

                    line = "";
                    for (int j = 0; j <= 9; j++)
                    {
                        for (int k = 0; k <= 9; k++)
                        {
                            line += ((float)(255 - compressed2.GetPixel(k, j).R) / 255).ToString() + " ";
                        }
                    }

                    for (int j = 1; j <= figure; j++)
                    {
                        line += "-1 ";
                    }
                    line += "1 ";
                    for (int j = figure; j <= NFIGURES - 2; j++)
                    {
                        line += "-1 ";
                    }
                    line = line.Replace(',', '.');
                    sw.WriteLine(line);
                    prbGeneration.PerformStep();
                }
                sw.Close();
                prbGeneration.Value = 0;
            }
            else
            {
                MessageBox.Show("Недопустимое значение");
            }
        }

        private void btnTrain_Click(object sender, EventArgs e)
        {
            //тренировка нейросети
            uint num_input = 100;
            uint num_output = NFIGURES;
            uint num_layers = 5;
            uint num_hidden_1 = 100;
            uint num_hidden_2 = 100;
            uint num_hidden_3 = 100;
            uint max_epochs = 10000;
            uint epochs_between = 1000;
            float error = 0.000001f;

            net = new NeuralNet(NetworkType.LAYER, num_layers, num_input, num_hidden_1, num_hidden_2, num_hidden_3, num_output);

            using (net)
            {
                net.ActivationFunctionHidden = ActivationFunction.SIGMOID_SYMMETRIC;
                net.ActivationFunctionOutput = ActivationFunction.SIGMOID_SYMMETRIC;
                net.TrainOnFile("training.data", max_epochs, epochs_between, error);
                File.WriteAllText("pic_recognition.net", "");
                net.Save("pic_recognition.net");
            }
        }

        private void picInput1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastPoint = e.Location;
        }

        private void picInput1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
            lastPoint = Point.Empty;
            if (pic1 != null)
            {
                cropped1 = crop_pic(pic1);               
                compressed1 = compress_pic(cropped1, 10, 10);
                picCompressed1.Image = compressed1;
                if (File.Exists("pic_recognition.net"))
                {
                    net = new NeuralNet("pic_recognition.net");
                    input = new float[100];
                    for (int i = 0; i <= 9; i++)
                    {
                        for (int j = 0; j <= 9; j++)
                        {
                            input[10 * i + j] = (float)(255 - compressed1.GetPixel(j, i).R) / 255;
                        }
                    }
                    output = net.Run(input);
                    percentage = new double[NFIGURES];
                    for (int i = 0; i <= NFIGURES - 1; i++)
                    {
                        percentage[i] = Math.Round((16 * Math.Pow((output[i] + 1) / 2 - 0.5, 5) + 0.5) * 100, 3); //формула, приближающая значение к 50%, чтобы значения были не только 0% и 100%
                    }
                    figure_names = new string[NFIGURES];
                    figure_names[0] = "Эллипс";
                    figure_names[1] = "Прямоугольник";
                    figure_names[2] = "Треугольник";
                    figure_names[3] = "Крест";
                    figure_names[4] = "Линия";
                    for (int i = 0; i < percentage.Length - 1; i++)
                    {
                        for (int j = 0; j < percentage.Length - i - 1; j++)
                        {
                            if (percentage[j + 1] > percentage[j])
                            {
                                tmp_double = percentage[j + 1];
                                percentage[j + 1] = percentage[j];
                                percentage[j] = tmp_double;

                                tmp_string = figure_names[j + 1];
                                figure_names[j + 1] = figure_names[j];
                                figure_names[j] = tmp_string;
                            }
                        }
                    }

                    pic_guess = new Bitmap(100, 50);
                    g_guess = Graphics.FromImage(pic_guess);
                    g_guess.FillRectangle(background, 0, 0, pic_guess.Width, pic_guess.Height); //фон
                    for (int i = 0; i <= percentage.Length - 1; i++)
                    {
                        
                        g_guess.FillRectangle(new SolidBrush(Color.Yellow), 0, 10 * i, (int)Math.Ceiling(percentage[i]), 10);
                        g_guess.DrawString(figure_names[i] + " " + percentage[i].ToString() + "%", new Font("Arial", 5), new SolidBrush(Color.Red), 1, 1 + 10 * i);
                    }
                    picGuess.Image = pic_guess;
                    
                }
            }
        }

        private void picInput1_MouseMove(object sender, MouseEventArgs e)
        {
            //рисование на PictureBox
            if (mouseDown)
            {
                if (pic1 == null)
                {
                    pic1 = new Bitmap(picInput1.Width, picInput1.Height);
                    g1 = Graphics.FromImage(pic1);
                    g1.FillRectangle(background, 0, 0, pic1.Width, pic1.Height); //фон
                    picInput1.Image = pic1;
                    pen_line = new Pen(Color.Black, 15);
                    pen_line.StartCap = LineCap.Round;
                    pen_line.EndCap = LineCap.Round;
                }
                g1.FillEllipse(b, e.Location.X - 7, e.Location.Y - 7, 15, 15);
                g1.DrawLine(pen_line, lastPoint, e.Location);
                g1.SmoothingMode = SmoothingMode.None;
                picInput1.Invalidate();
                lastPoint = e.Location;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //очистка холста
            pic1 = null;
            picInput1.Image = null;
            picCompressed1.Image = null;
            picGuess.Image = null;
        }

        private Bitmap generate_pic(int index)
        {
            //функция для генерации фигуры
            bmp = new Bitmap(100, 100);
            g2 = Graphics.FromImage(bmp);
            rnd = new Random(System.Environment.TickCount + seed);

            pen_width = rnd.Next(5, 11);
            p = new Pen(Color.Black, pen_width);

            p.StartCap = LineCap.Round; //скругленные концы при рисовании линий
            p.EndCap = LineCap.Round;

            g2.FillRectangle(background, 0, 0, bmp.Width, bmp.Height); //фон

            //генерирует как идеальные фигуры, так и неровные, поскольку человек не всегда способен нарисовать идеально
            switch (index)
            {
                case 0:
                    //эллипс
                    if (rnd.Next(5) > 0)
                    {
                        //обычный эллипс
                        x = rnd.Next(pen_width, 50 - pen_width);
                        y = rnd.Next(pen_width, 50 - pen_width);
                        w = rnd.Next(pen_width + 10, 90 - x);
                        h = rnd.Next(pen_width + 10, 90 - y);

                        if (rnd.Next(5) > 0)
                        {
                            //пустой
                            g2.DrawEllipse(p, x, y, w, h);
                        }
                        else
                        {
                            //в 20% случаев закрашенный
                            g2.FillEllipse(b, x, y, w, h);
                        }
                    }
                    else
                    {
                        //в 20% случаев слегка прямоугольный
                        path = new GraphicsPath();

                        x = rnd.Next(pen_width, 50 - pen_width);
                        y = rnd.Next(pen_width, 50 - pen_width);
                        w = rnd.Next(pen_width + 10, 70 - x);
                        h = Math.Min(w, 90 - y);
                        bounds = new Rectangle(x, y, w, h);
                        diameter = Math.Min(w, h) / 2 + 5;
                        arc = new Rectangle(bounds.X, bounds.Y, diameter, diameter);

                        path.AddArc(arc, 180, 90);
                        arc.X = bounds.Right - diameter;
                        path.AddArc(arc, 270, 90);
                        arc.Y = bounds.Bottom - diameter;
                        path.AddArc(arc, 0, 90);
                        arc.X = bounds.Left;
                        path.AddArc(arc, 90, 90);
                        path.CloseFigure();
                        g2.DrawPath(p, path);
                    }

                    break;


                case 1:
                    //прямоугольник
                    points = new Point[4];
                    points[0] = new Point(rnd.Next(pen_width * 2, 50 - pen_width * 2), rnd.Next(pen_width * 2, 50 - pen_width * 2));
                    w = rnd.Next(50 + pen_width * 2 - points[0].X, 100 - pen_width * 2 - points[0].X);
                    h = rnd.Next(50 + pen_width * 2 - points[0].Y, 100 - pen_width * 2 - points[0].Y);
                    points[1] = new Point(points[0].X + w, points[0].Y);
                    points[2] = new Point(points[0].X + w, points[0].Y + h);
                    points[3] = new Point(points[0].X, points[0].Y + h);

                    if (rnd.Next(2) > 0)
                    {
                        //в половине случаев смещает все вершины, делая прямоугольник немного неровным
                        for (int i = 0; i <= 3; i++)
                        {
                            points[i].X = rnd.Next(Math.Max(0, points[i].X - 5), Math.Min(points[i].X + 5, 98) + 1);
                            points[i].Y = rnd.Next(Math.Max(0, points[i].Y - 5), Math.Min(points[i].Y + 5, 98) + 1);
                        }
                    }
                    if (rnd.Next(5) > 0)
                    {
                        //пустой
                        if (rnd.Next(2) > 0)
                        {
                            //с острыми углами
                            g2.DrawPolygon(p, points);
                        }
                        else
                        {
                            //со скругленными углами
                            g2.DrawLine(p, points[0], points[1]);
                            g2.DrawLine(p, points[1], points[2]);
                            g2.DrawLine(p, points[2], points[3]);
                            g2.DrawLine(p, points[3], points[0]);
                        }
                    }
                    else
                    {
                        //в 20% случаев закрашенный
                        g2.FillPolygon(b, points);
                    }
                    break;


                case 2:
                    //треугольник
                    points = new Point[3];
                    //делит все поле на 2 четверти и 1 половину 4 способами (иначе некоторые вариации треугольников будут чаще), каждая из точек строго в своей части
                    switch (rnd.Next(4))
                    {
                        case 0:
                            points[0] = new Point(rnd.Next(0, 50 - pen_width * 2), rnd.Next(0, 50 - pen_width * 2));
                            points[1] = new Point(rnd.Next(0, 50 - pen_width * 2), rnd.Next(50 + pen_width * 2, 100));
                            points[2] = new Point(rnd.Next(50 + pen_width * 2, 100), rnd.Next(0, 100));
                            break;

                        case 1:
                            points[0] = new Point(rnd.Next(0, 50 - pen_width * 2), rnd.Next(0, 50 - pen_width * 2));
                            points[1] = new Point(rnd.Next(50 + pen_width * 2, 100), rnd.Next(0, 50 - pen_width * 2));
                            points[2] = new Point(rnd.Next(0, 100), rnd.Next(50 + pen_width * 2, 100));
                            break;

                        case 2:
                            points[0] = new Point(rnd.Next(50 + pen_width * 2, 100), rnd.Next(0, 50 - pen_width * 2));
                            points[1] = new Point(rnd.Next(50 + pen_width * 2, 100), rnd.Next(50 + pen_width * 2, 100));
                            points[2] = new Point(rnd.Next(0, 50 - pen_width * 2), rnd.Next(0, 100));
                            break;

                        case 3:
                            points[0] = new Point(rnd.Next(0, 50 - pen_width * 2), rnd.Next(50 + pen_width * 2, 100));
                            points[1] = new Point(rnd.Next(50 + pen_width * 2, 100), rnd.Next(50 + pen_width * 2, 100));
                            points[2] = new Point(rnd.Next(0, 100), rnd.Next(0, 50 - pen_width * 2));
                            break;
                    }
                    if (rnd.Next(5) > 0)
                    {
                        //пустой
                        if (rnd.Next(2) > 0)
                        {
                            //с острыми углами
                            g2.DrawPolygon(p, points);
                        }
                        else
                        {
                            //со скругленными углами
                            g2.DrawLine(p, points[0], points[1]);
                            g2.DrawLine(p, points[1], points[2]);
                            g2.DrawLine(p, points[2], points[0]);
                        }
                    }
                    else
                    {
                        //в 20% случаев закрашенный
                        g2.FillPolygon(b, points);
                    }
                    break;


                case 3:
                    //крест
                    if (rnd.Next(2) > 0)
                    {
                        //в форме X
                        points = new Point[4];
                        points[0] = new Point(rnd.Next(pen_width * 2, 50 - pen_width * 2), rnd.Next(pen_width * 2, 50 - pen_width * 2));
                        points[1] = new Point(rnd.Next(50 + pen_width * 2, 100 - pen_width * 2), rnd.Next(pen_width * 2, 50 - pen_width * 2));
                        points[2] = new Point(rnd.Next(pen_width * 2, 50 - pen_width * 2), rnd.Next(50 + pen_width * 2, 100 - pen_width * 2));
                        points[3] = new Point(rnd.Next(50 + pen_width * 2, 100 - pen_width * 2), rnd.Next(50 + pen_width * 2, 100 - pen_width * 2));
                        g2.DrawLine(p, points[0], points[3]);
                        g2.DrawLine(p, points[1], points[2]);
                    }
                    else
                    {
                        //в форме +
                        points = new Point[4];
                        points[0] = new Point(rnd.Next(25 + pen_width * 2, 75 - pen_width * 2), rnd.Next(pen_width * 2, 50 - pen_width * 2));
                        points[1] = new Point(rnd.Next(50 + pen_width * 2, 100 - pen_width * 2), rnd.Next(25 + pen_width * 2, 75 - pen_width * 2));
                        points[2] = new Point(rnd.Next(25 + pen_width * 2, 75 - pen_width * 2), rnd.Next(50 + pen_width * 2, 100 - pen_width * 2));
                        points[3] = new Point(rnd.Next(pen_width * 2, 50 - pen_width * 2), rnd.Next(25 + pen_width * 2, 75 - pen_width * 2));

                        g2.DrawLine(p, points[0], points[2]);
                        g2.DrawLine(p, points[1], points[3]);
                    }

                    break;


                case 4:
                    //линия
                    if (rnd.Next(3) > 0)
                    {
                        //прямая
                        points = new Point[2];
                        if (rnd.Next(2) > 0)
                        {
                            points[0] = new Point(rnd.Next(0, 100), rnd.Next(0, 50 - 2 * pen_width));
                            points[1] = new Point(rnd.Next(0, 100), rnd.Next(50 + 2 * pen_width, 100));
                        }
                        else
                        {
                            points[0] = new Point(rnd.Next(0, 50 - 2 * pen_width), rnd.Next(0, 100));
                            points[1] = new Point(rnd.Next(50 + 2 * pen_width, 100), rnd.Next(0, 100));
                        }
                        g2.DrawLine(p, points[0], points[1]);
                    }
                    else
                    {
                        //кривая
                        x = rnd.Next(pen_width, 50 - pen_width);
                        y = rnd.Next(pen_width, 50 - pen_width);
                        w = rnd.Next(pen_width + 10, 90 - x);
                        h = rnd.Next(pen_width + 10, 90 - y);
                        g2.DrawArc(p, x, y, w, h, rnd.Next(360), rnd.Next(30, 91));
                    }
                    break;

            }
            return bmp;
        }

        private Bitmap crop_pic(Bitmap original)
        {
            //функция для обрезки изображения
            empty = true; //true, если в i-той строчке нет черных пикселей
            for (int i = 1; i <= original.Width - 1; i++) //начиная с 1, т.к. иначе может сделать координату -1
            {
                for (int j = 0; j <= original.Height - 1; j++)
                {
                    if (original.GetPixel(i, j).R == 0)
                    {
                        empty = false;
                        break;
                    }
                }
                if (!empty)
                {
                    cropx1 = i - 1;
                    break;
                }
            }

            empty = true;
            for (int i = 1; i <= original.Height - 1; i++) //начиная с 1, т.к. иначе может сделать координату -1
            {
                for (int j = 0; j <= original.Width - 1; j++)
                {
                    if (original.GetPixel(j, i).R == 0)
                    {
                        empty = false;
                        break;
                    }
                }
                if (!empty)
                {
                    cropy1 = i - 1;
                    break;
                }
            }

            empty = true;
            for (int i = original.Width - 2; i >= 0; i--) //начиная с 98, т.к. иначе может сделать координату 100
            {
                for (int j = 0; j <= original.Height - 1; j++)
                {
                    if (original.GetPixel(i, j).R == 0)
                    {
                        empty = false;
                        break;
                    }
                }
                if (!empty)
                {
                    cropx2 = i + 1;
                    break;
                }
            }

            empty = true;
            for (int i = original.Height - 2; i >= 0; i--) //начиная с 98, т.к. иначе может сделать координату 100
            {
                for (int j = 0; j <= original.Width - 1; j++)
                {
                    if (original.GetPixel(j, i).R == 0)
                    {
                        empty = false;
                        break;
                    }
                }
                if (!empty)
                {
                    cropy2 = i + 1;
                    break;
                }
            }

            side = Math.Max(cropx2 - cropx1, cropy2 - cropy1);
            side = Math.Min(side, Math.Min(original.Width, original.Height));

            if (cropx1 + side < original.Width - 1)
            {
                x0 = cropx1;
            }
            else
            {
                x0 = Math.Max(0, cropx2 - side);
            }

            if (cropy1 + side < original.Height - 1)
            {
                y0 = cropy1;
            }
            else
            {
                y0 = Math.Max(0, cropy2 - side);
            }

            cloneRect = new Rectangle(x0, y0, side, side);
            bmp = original.Clone(cloneRect, original.PixelFormat);
            return bmp;
        }

        private Bitmap compress_pic(Bitmap original, int w_new, int h_new)
        {
            //функция для сжатия изображения
            bmp = new Bitmap(w_new, h_new);
            using (var graphics = Graphics.FromImage(bmp))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                //graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    cloneRect = new Rectangle(0, 0, w_new, h_new);
                    graphics.DrawImage(original, cloneRect, 0, 0, original.Width, original.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }
            return bmp;
        }

        
    }
}
