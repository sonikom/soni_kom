﻿namespace Image_Recognition
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.picGuess = new System.Windows.Forms.PictureBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.picCompressed1 = new System.Windows.Forms.PictureBox();
            this.picInput1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnTrain = new System.Windows.Forms.Button();
            this.prbGeneration = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDataAmount = new System.Windows.Forms.TextBox();
            this.btnGenerateData = new System.Windows.Forms.Button();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.cmbFigure = new System.Windows.Forms.ComboBox();
            this.picCompressed2 = new System.Windows.Forms.PictureBox();
            this.picInput2 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picGuess)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompressed1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInput1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCompressed2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInput2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(9, 10);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(568, 430);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.picGuess);
            this.tabPage1.Controls.Add(this.btnClear);
            this.tabPage1.Controls.Add(this.picCompressed1);
            this.tabPage1.Controls.Add(this.picInput1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(560, 404);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Работа с нейросетью";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // picGuess
            // 
            this.picGuess.BackColor = System.Drawing.SystemColors.Control;
            this.picGuess.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picGuess.Location = new System.Drawing.Point(352, 4);
            this.picGuess.Name = "picGuess";
            this.picGuess.Size = new System.Drawing.Size(203, 122);
            this.picGuess.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picGuess.TabIndex = 4;
            this.picGuess.TabStop = false;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(4, 253);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 32);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Очистить";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // picCompressed1
            // 
            this.picCompressed1.BackColor = System.Drawing.SystemColors.Control;
            this.picCompressed1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCompressed1.Location = new System.Drawing.Point(234, 4);
            this.picCompressed1.Margin = new System.Windows.Forms.Padding(2);
            this.picCompressed1.Name = "picCompressed1";
            this.picCompressed1.Size = new System.Drawing.Size(113, 122);
            this.picCompressed1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCompressed1.TabIndex = 1;
            this.picCompressed1.TabStop = false;
            // 
            // picInput1
            // 
            this.picInput1.BackColor = System.Drawing.Color.White;
            this.picInput1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picInput1.Location = new System.Drawing.Point(4, 4);
            this.picInput1.Margin = new System.Windows.Forms.Padding(2);
            this.picInput1.Name = "picInput1";
            this.picInput1.Size = new System.Drawing.Size(226, 244);
            this.picInput1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picInput1.TabIndex = 0;
            this.picInput1.TabStop = false;
            this.picInput1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picInput1_MouseDown);
            this.picInput1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picInput1_MouseMove);
            this.picInput1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picInput1_MouseUp);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnTrain);
            this.tabPage2.Controls.Add(this.prbGeneration);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.txtDataAmount);
            this.tabPage2.Controls.Add(this.btnGenerateData);
            this.tabPage2.Controls.Add(this.btnGenerate);
            this.tabPage2.Controls.Add(this.cmbFigure);
            this.tabPage2.Controls.Add(this.picCompressed2);
            this.tabPage2.Controls.Add(this.picInput2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(560, 404);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Тренировка нейросети";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnTrain
            // 
            this.btnTrain.Location = new System.Drawing.Point(5, 106);
            this.btnTrain.Name = "btnTrain";
            this.btnTrain.Size = new System.Drawing.Size(150, 40);
            this.btnTrain.TabIndex = 10;
            this.btnTrain.Text = "Тренировать нейросеть";
            this.btnTrain.UseVisualStyleBackColor = true;
            this.btnTrain.Click += new System.EventHandler(this.btnTrain_Click);
            // 
            // prbGeneration
            // 
            this.prbGeneration.Location = new System.Drawing.Point(5, 77);
            this.prbGeneration.Name = "prbGeneration";
            this.prbGeneration.Size = new System.Drawing.Size(150, 23);
            this.prbGeneration.Step = 1;
            this.prbGeneration.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Кол-во данных:";
            // 
            // txtDataAmount
            // 
            this.txtDataAmount.Location = new System.Drawing.Point(95, 51);
            this.txtDataAmount.Name = "txtDataAmount";
            this.txtDataAmount.Size = new System.Drawing.Size(60, 20);
            this.txtDataAmount.TabIndex = 7;
            this.txtDataAmount.Text = "500";
            // 
            // btnGenerateData
            // 
            this.btnGenerateData.Location = new System.Drawing.Point(5, 5);
            this.btnGenerateData.Name = "btnGenerateData";
            this.btnGenerateData.Size = new System.Drawing.Size(150, 40);
            this.btnGenerateData.TabIndex = 6;
            this.btnGenerateData.Text = "Создать базу";
            this.btnGenerateData.UseVisualStyleBackColor = true;
            this.btnGenerateData.Click += new System.EventHandler(this.btnGenerateData_Click);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(284, 5);
            this.btnGenerate.Margin = new System.Windows.Forms.Padding(2);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(120, 40);
            this.btnGenerate.TabIndex = 3;
            this.btnGenerate.Text = "Создать 1 фигуру";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // cmbFigure
            // 
            this.cmbFigure.FormattingEnabled = true;
            this.cmbFigure.Items.AddRange(new object[] {
            "Эллипс",
            "Прямоугольник",
            "Треугольник",
            "Крест",
            "Линия"});
            this.cmbFigure.Location = new System.Drawing.Point(284, 49);
            this.cmbFigure.Margin = new System.Windows.Forms.Padding(2);
            this.cmbFigure.Name = "cmbFigure";
            this.cmbFigure.Size = new System.Drawing.Size(120, 21);
            this.cmbFigure.TabIndex = 2;
            // 
            // picCompressed2
            // 
            this.picCompressed2.BackColor = System.Drawing.SystemColors.Control;
            this.picCompressed2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCompressed2.Location = new System.Drawing.Point(406, 172);
            this.picCompressed2.Margin = new System.Windows.Forms.Padding(2);
            this.picCompressed2.Name = "picCompressed2";
            this.picCompressed2.Size = new System.Drawing.Size(150, 163);
            this.picCompressed2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCompressed2.TabIndex = 1;
            this.picCompressed2.TabStop = false;
            // 
            // picInput2
            // 
            this.picInput2.BackColor = System.Drawing.SystemColors.Control;
            this.picInput2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picInput2.Location = new System.Drawing.Point(406, 5);
            this.picInput2.Margin = new System.Windows.Forms.Padding(2);
            this.picInput2.Name = "picInput2";
            this.picInput2.Size = new System.Drawing.Size(150, 163);
            this.picInput2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picInput2.TabIndex = 0;
            this.picInput2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 449);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Распознавание изображений";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picGuess)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCompressed1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInput1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCompressed2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picInput2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.ComboBox cmbFigure;
        private System.Windows.Forms.PictureBox picCompressed2;
        private System.Windows.Forms.PictureBox picInput2;
        private System.Windows.Forms.Button btnGenerateData;
        private System.Windows.Forms.TextBox txtDataAmount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ProgressBar prbGeneration;
        private System.Windows.Forms.Button btnTrain;
        private System.Windows.Forms.PictureBox picCompressed1;
        private System.Windows.Forms.PictureBox picInput1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.PictureBox picGuess;
    }
}

